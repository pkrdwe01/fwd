30 mtime=1712016875.298600269
70 LIBARCHIVE.xattr.com.apple.quarantine=MDA4MTs2NjBiNGI2NDtDaHJvbWU7
59 SCHILY.xattr.com.apple.quarantine=0081;660b4b64;Chrome;
